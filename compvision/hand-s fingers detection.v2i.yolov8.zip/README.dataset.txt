# hand's fingers detection > 2022-08-10 2:31pm
https://universe.roboflow.com/tryingroboflow/hand-s-fingers-detection

Provided by a Roboflow user
License: Public Domain

