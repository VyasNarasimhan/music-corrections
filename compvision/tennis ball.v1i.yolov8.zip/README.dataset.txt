# tennis ball > 2022-06-11 6:52pm
https://universe.roboflow.com/tennis-3ll0a/tennis-ball-icifx

Provided by a Roboflow user
License: Public Domain

